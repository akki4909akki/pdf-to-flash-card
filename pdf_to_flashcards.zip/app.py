from flask import Flask, request, jsonify
import fitz  # PyMuPDF
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def extract_flashcards_from_pdf(file):
    doc = fitz.open(stream=file.read(), filetype="pdf")
    flashcards = []
    for page in doc:
        text = page.get_text()
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        for i in range(len(lines) - 1):
            if lines[i].endswith("?"):
                flashcards.append({
                    "question": lines[i],
                    "answer": lines[i + 1]
                })
    return flashcards

@app.route("/upload", methods=["POST"])
def upload():
    if 'pdf' not in request.files:
        return jsonify({"error": "No PDF uploaded"}), 400
    pdf = request.files['pdf']
    flashcards = extract_flashcards_from_pdf(pdf)
    return jsonify(flashcards)

if __name__ == '__main__':
    app.run(debug=True)
